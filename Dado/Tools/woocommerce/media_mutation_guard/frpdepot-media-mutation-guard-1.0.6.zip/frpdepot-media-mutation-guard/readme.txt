=== FRP Depot Media Mutation Guard ===
Contributors: frpdepot
Requires at least: 6.4
Requires PHP: 8.0
Stable tag: 1.0.6
License: Proprietary

Fixed internal safety plugin for FRP Depot's approved five-family product-gallery workflow,
including the staged 2026 catalogue-image update for the filament-wound pipe family,
the accepted six-view Stub Flange set, and the accepted six-view Open Manway set.

It serializes in-scope WordPress attachment mutations with one hard-coded MySQL advisory
lock. While that lock is held, it builds complete original-file SHA-256 snapshots and
reads/writes one versioned guard row directly in a fixed InnoDB table, bypassing the
WordPress option and object caches. Database UTC controls the fixed 30-minute expiry.

One fixed exception exists for intentionally private Hetron attachment 1832. Readable or
unreadable, a snapshot accepts it only when its complete attachment identity remains exact
and the active Hetron protector plugin's live PHP source matches its pinned SHA-256. The
protected attachment is represented in the snapshot digest; every other non-trash
attachment must still expose a readable original file and fresh hash.

One owner-bound guard permits only the selected family's exact byte-pinned PNG set: six
images each for Stub Flange and Open Manway and four for each other fixed family. Stub
Flange remains the sole general reuse exception, unchanged and not generalized. Acquisition
requires product 1368 to have exactly one raw `_thumbnail_id` value `4849`, exactly one raw
`_product_image_gallery` value `4850,4851,4852`, and attachment 4849's freshly rehashed
original file to remain exactly `01_stub_flange_real_source_hero-1.png`, 895251 bytes, and
the approved SHA-256. Exactly that one hash conflict and no filename or other hash conflict
is accepted. Position 1 is bound durably to attachment 4849 in the versioned JSON state
record and can never be uploaded; only positions 2-6 may be reserved and bound, in order,
to five distinct new IDs.

= 1.0.6: the one literal Open Manway recovery contract =

Version 1.0.6 adds exactly one new capability, and nothing generic. The durable state
record is schema 3: it stores the contract name, the attachment bindings established at
acquisition, the immutable list of missing positions, and the append-only list of reserved
uploads. Every later decision -- including which upload is permitted next -- is derived
from that row and never from a caller.

The recovery contract names one family (`open_manway`), one product 1397, one prior
indeterminate operation `e0127fcaa04c023cbdd19a36726d6e8f03c3fb01f12f0367550d17c87674dc85`,
and one verified prior upload: attachment 7609, `01_manway_premium_hero.png`, 1750111 bytes,
SHA-256 `472b5e5b0aba9a7201444524c559e6797c266a0de008d7bc70b4f8ef1938d0cd`, bound at fixed
position 1. Positions 2-6 may each bind to exactly zero or one live attachment, proved by
complete server-side rehashing plus the origin-file proof below; every remaining position
becomes an immutable missing-position entry that may be reserved and uploaded once, in
ascending order, even when the first missing position is 2 or later. No other family,
product, attachment, filename, path or action can reach this branch, and it never deletes,
detaches, renames or edits anything.

Acquiring the recovery contract additionally requires a bounded, fail-closed origin-only
file proof. It inspects only the six fixed Open Manway basenames, only inside the WordPress
base upload directory and its supported `YYYY/MM` organisation directories, with no
caller-supplied path, glob or pattern. Each discovered object must be a contained regular
file with no symlink or reparse-style alias, is measured and rehashed, and is correlated to
exact `_wp_attached_file` ownership. Only safe relative paths, the fixed position, byte and
hash classification and owning attachment IDs are reported; no absolute server path is
disclosed. A fixed basename that exists without exactly one safe owning attachment is an
origin-only blocker and refuses acquisition before any state row is inserted; an environment
that cannot prove complete enumeration refuses in the same way. The plugin never deletes or
adopts such a file.

= Gallery commit =

For an ordinary family the exact set is captured and one images-only WooCommerce REST `PUT`
must carry those six ordered IDs as its sole JSON parameter, no query/form/file parameters,
from the same owner user, WordPress session, and guard token. The request must also carry a
non-secret `If-Match` SHA-256 of the complete live pre-write gallery ID list. Under the same
advisory lock, the guard revalidates the exact raw Stub Flange baseline metadata and that
precondition, then atomically moves its row from `active` to `gallery` before permitting
only those exact featured/gallery metadata values.

The Open Manway recovery contract commits through one fixed authenticated admin-post route
instead, because the guard's owner check needs the exact WordPress user, a nonempty session
token and the guard secret cookie, and that cookie is deliberately scoped to `/wp-admin/`.
The route accepts nothing but its action, its exact nonce and the plan-pinned non-secret
`If-Match` gallery hash: no product, family, attachment ID, filename, path, URL or arbitrary
payload field exists in the form or the handler. Product 1397 and the six ordered IDs are
derived exclusively from the guard record and the fixed manifest, the live gallery and
precondition are re-read under the advisory lock, and one internal images-only
`rest_do_request` update runs inside the same authenticated request so the existing
`woocommerce_rest_pre_insert_product_object` filter sees the owner and performs the one
atomic `active` to `gallery` claim. There is no external loopback HTTP, consumer key,
generic REST route, browser-supplied image ID, product edit form, retry, rollback or cleanup
endpoint, and any uncertainty leaves the row's normal no-retry expiry behaviour intact.

Ordinary and metadata-by-ID post-meta APIs resolve aliases with the live `meta_key` column's
exact MySQL character set and collation, failing closed if that schema proof is unavailable,
so competing gallery writes remain blocked until completion or expiry. WordPress core's
alternate-image filename collision scan remains enabled and is never overridden by this plugin.
Completion is not a cancel or cleanup route: it succeeds only after a fresh complete
Media Library rehash proves the baseline attachment count plus exactly the reserved uploads,
the captured bindings plus those uploads as distinct IDs, and the fixed WooCommerce product
proves the same featured/gallery IDs in manifest order. The guard row is retained with
terminal status `completed`; an expired `active` or `gallery` row is retained as `expired`.
Neither path deletes attachments or product data.

The locking contract requires one authoritative MySQL server. It does not claim safety
through a read/write split, proxy connection multiplexing, pooled-connection behavior
that changes lock ownership, or independent primaries. There is no force-unlock or
age-based advisory-lock reclamation; stale recovery requires explicit DBA termination
of the owning database connection.

This is an ordinary WordPress plugin. Its enforcement boundary excludes direct database
or filesystem mutation, malicious PHP running in the same process, and a privileged
administrator who disables or replaces the plugin. Extending protection to those actors
would require an MU-plugin or host-level control.

There is no public endpoint, REST write route, generic filename/hash/product input,
attachment delete route, product/order/customer/payment operation, or email transport.
Installation and activation are separately approval-gated by the commissioned fixed
deployment tool.
