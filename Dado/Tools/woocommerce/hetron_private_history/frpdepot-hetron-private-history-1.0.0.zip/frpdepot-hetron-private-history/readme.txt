=== FRP Depot Hetron Private History ===
Contributors: frpdepot
Requires at least: 6.0
Requires PHP: 8.0
Stable tag: 1.0.0

A fixed, non-configurable retirement mechanism for WordPress attachment 1832.

After activation, an exact authenticated protect action (and only when attachment
1832 is already private) verifies the full byte count and SHA-256 of one fixed PDF
and four fixed JPEG previews, then renames those five exact files to a fixed
directory one level above the document root. The public upload paths therefore
become 404 without deleting or changing the historical bytes. Activation alone
does not move a historical file.

Five fixed authenticated admin-post actions provide historical downloads only
to a signed-in user who can upload files and read private attachment 1832. Every
download is hash-verified immediately before it is streamed.

One exact authenticated restore action is the reverse move after a complete
preflight. Deactivation itself never restores, moves or deletes a historical
file. The deployment tool deliberately cannot call restore; exposing the five
public paths again requires a separately commissioned, approval-gated capability.

The five-file transition is not atomic as a set. Each individual same-filesystem
rename is atomic. A failure after one rename is indeterminate and requires manual
reconciliation; activation performs no automatic retry or rollback.
